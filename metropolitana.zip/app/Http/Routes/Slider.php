<?php
 Route::get('api/slider', 'SliderController@getAll');  
