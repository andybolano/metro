<?php
 Route::post('api/autenticar', 'UsuarioController@autenticar');   